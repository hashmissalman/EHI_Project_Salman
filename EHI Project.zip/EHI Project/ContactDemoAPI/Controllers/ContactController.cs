﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;
using ContactDemoDTO;
using Microsoft.Extensions.Configuration;
using ContactDemoBO;

namespace ContactDemoAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ContactController : ControllerBase
    {
        #region Constructors
        private readonly IConfiguration _configuration;
        public ContactController(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        #endregion

        #region Get All Contacs
        /// <summary>
        /// This API will return list of all contacts
        /// </summary>
        /// <returns> </returns>
        [HttpGet]
        [Route("ContactAll")]
        public async Task<IActionResult> ContactsGetAllAsync()
        {
            try
            {
                ContactBO CBO = new ContactBO();
                return Ok(await CBO.ContactGetAllAsync());
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        #endregion

        #region Get Contact Details
        /// <summary>
        /// This API will return detail of selected contact
        /// <param name="ContactID"></param>
        /// </summary>
        /// <returns> Contact Details</returns>
        [HttpGet]
        [Route("ContactDetails")]
        public async Task<IActionResult> ContactGetDetailsByIDAsync(int ContactID)
        {
            try
            {
                ContactBO CBO = new ContactBO();
                return Ok(await CBO.ContactGetDetailsByIDAsync(ContactID));
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        #endregion

        #region Save Update Contact
        /// <summary>
        /// This API will save or update contact based on Contact Id 
        /// <param name="ContactCreateUpdateDTO"></param>
        /// </summary>
        /// <returns> status of operation </returns>
        [HttpPost]
        // [Authorize]
        [Route("Contact")]
        public async Task<IActionResult> ContactSaveUpdateAsync(ContactCreateUpdateDTO contact)
        {
            try
            {
                ContactBO CBO = new ContactBO();
                OperationResposneDTO result = await CBO.ContactSaveUpdateAsync(contact);
                if (result.Status == 1) return Ok(result.Message.ToString());
                else return BadRequest(result.Message.ToString());
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        #endregion

        #region Update Contact Status
        /// <summary>
        /// This API will  update contact status  on Contact Id 
        /// <param name="int ContactID, bool Status"></param>
        /// </summary>
        /// <returns> status of operation </returns>
        [HttpPut]
        // [Authorize]
        [Route("Contact")]
        public async Task<IActionResult> ContactStausUpdateAsync(int ContactID, string Status)
        {
            try
            {
                ContactBO CBO = new ContactBO();
                OperationResposneDTO result = await CBO.ContactStatusUpdateAsync(ContactID, Status);
                if (result.Status == 1) return Ok(result.Message.ToString());
                else return BadRequest(result.Message.ToString());
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        #endregion

        #region  Delete Contact 
        /// <summary>
        /// This API will  Delete Contact
        /// <param name="int ContactID"></param>
        /// </summary>
        /// <returns> status of operation </returns>
        [HttpDelete]
        // [Authorize]
        [Route("Contact")]
        public async Task<IActionResult> ContactDeleteAsync(int ContactID)
        {
            try
            {
                ContactBO CBO = new ContactBO();
                OperationResposneDTO result = await CBO.ContactDeleteAsync(ContactID);
                if (result.Status == 1) return Ok(result.Message.ToString());
                else return BadRequest(result.Message.ToString());
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        #endregion
    }
}
