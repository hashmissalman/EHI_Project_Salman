﻿using ContactDemoDTO;
using Dapper;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using static ContactDemoDTO.Common;

namespace ContactDemoDAO
{
    public class ContactDAO
    {
        #region Get all contacts
        public async Task<List<ContactListDTO>> ContactGetAllAsync()
        {
            using (IDbConnection conn = new SqlConnection(ApplicationSettings.DbConnectionString))
            {
                var lstContacts = await conn.QueryAsync<ContactListDTO>("[sp_Contact_GetList]", commandType: CommandType.StoredProcedure);
                return lstContacts.ToList();
            }
        }
        #endregion

        #region Get Contact Details
        public async Task<ContactDetailsDTO> ContactGetDetailsByIDAsync(int ContactID)
        {

            using (IDbConnection conn = new SqlConnection(ApplicationSettings.DbConnectionString))
            {
                return await conn.QueryFirstOrDefaultAsync<ContactDetailsDTO>("[sp_Contact_GetDetailsByID]", new { ContactID }, commandType: CommandType.StoredProcedure);
            }
        }
        #endregion

        #region Save or Update Contact
        public async Task<OperationResposneDTO> ContactSaveUpdateAsync(ContactCreateUpdateDTO contact)
        {
            using (IDbConnection conn = new SqlConnection(ApplicationSettings.DbConnectionString))
            {
                string message = "";
                int status = 0;
                var para = new DynamicParameters();
                if (contact.ContactID > 0)
                    para.Add("ContactID", contact.ContactID);
                else
                    para.Add("ContactID", null);
                para.Add("FirstName", contact.FirstName);
                para.Add("LastName", contact.LastName);
                para.Add("Email", contact.Email);
                if (!string.IsNullOrEmpty(contact.PhoneNo) || contact.PhoneNo != "")
                    para.Add("PhoneNo", contact.PhoneNo);
                else
                    para.Add("PhoneNo", null);
                para.Add("ContactStatus", contact.ContactStatus);
                para.Add("OutStatus", status, direction: ParameterDirection.Output);
                para.Add("OutMessage", message, direction: ParameterDirection.Output);
                await conn.QueryAsync<int>("[sp_Contact_CreateUpdate]", para, commandType: CommandType.StoredProcedure);
                status = para.Get<int>("OutStatus");
                message = para.Get<string>("OutMessage");
                return new OperationResposneDTO { Status = status, Message = message };
            }

        }
        #endregion

        #region Update Contact Status
        public async Task<OperationResposneDTO> ContactStatusUpdateAsync(int ContactID, string Status)
        {
            using (IDbConnection conn = new SqlConnection(ApplicationSettings.DbConnectionString))
            {
                string message = "";
                int status = 0;
                var para = new DynamicParameters();
                para.Add("ContactID", ContactID);
                para.Add("ContactStatus", Status);
                para.Add("OutStatus", status, direction: ParameterDirection.Output);
                para.Add("OutMessage", message, direction: ParameterDirection.Output);
                await conn.QueryAsync<int>("[sp_Contact_UpdateStatus]", para, commandType: CommandType.StoredProcedure);
                status = para.Get<int>("OutStatus");
                message = para.Get<string>("OutMessage");
                return new OperationResposneDTO { Status = status, Message = message };
            }
        }
        #endregion

        #region Delete Contact
        public async Task<OperationResposneDTO> ContactDeleteAsync(int ContactID)
        {
            using (IDbConnection conn = new SqlConnection(ApplicationSettings.DbConnectionString))
            {
                string message = "";
                int status = 0;
                var para = new DynamicParameters();
                para.Add("ContactID", ContactID);
                para.Add("OutStatus", status, direction: ParameterDirection.Output);
                para.Add("OutMessage", message, direction: ParameterDirection.Output);
                await conn.QueryAsync<int>("[sp_Contact_Delete]", para, commandType: CommandType.StoredProcedure);
                status = para.Get<int>("OutStatus");
                message = para.Get<string>("OutMessage");
                return new OperationResposneDTO { Status = status, Message = message };
            }
        }
        #endregion
    }
}
