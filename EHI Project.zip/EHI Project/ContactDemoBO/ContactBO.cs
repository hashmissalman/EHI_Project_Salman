﻿using ContactDemoDAO;
using ContactDemoDTO;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ContactDemoBO
{
    public class ContactBO
    {

        #region Contact Save Update validation 
        public async Task<OperationResposneDTO> ContactSaveUpdateAsync(ContactCreateUpdateDTO contact)
        {
            if (contact.ContactStatus == "Active" || contact.ContactStatus == "Inactive")
            {
                ContactDAO CDAO = new ContactDAO();
                return await CDAO.ContactSaveUpdateAsync(contact);
            }
            else
                return new OperationResposneDTO { Status = 0, Message = "Status can either be Active or Inactive" };
        }
        #endregion

        #region Get all contacts
        public async Task<List<ContactListDTO>> ContactGetAllAsync()
        {
            ContactDAO contact = new ContactDAO();
            return await contact.ContactGetAllAsync();
        }

        #endregion

        #region Get Contact Details
        public async Task<ContactDetailsDTO> ContactGetDetailsByIDAsync(int ContactID)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(ContactID)))
            {
                if (ContactID > 0)
                {
                    ContactDAO contact = new ContactDAO();
                   return await contact.ContactGetDetailsByIDAsync(ContactID);
                }
                else
                    return null;
            }
            else
                return null;
        }
        #endregion

        #region Update Contact status Validation
        public async Task<OperationResposneDTO> ContactStatusUpdateAsync(int ContactID, string Status)
        {
            if (Status == "Active" || Status == "Inactive")
            {
                ContactDAO contact = new ContactDAO();
                return await contact.ContactStatusUpdateAsync(ContactID, Status);
            }
            else
                return new OperationResposneDTO { Status = 0, Message = "Status can either be active or inactive" };

            
        }
        #endregion

        #region Delete Contact business validation
        public async Task<OperationResposneDTO> ContactDeleteAsync(int ContactID)
        {
            if (ContactID > 0)
            {
                ContactDAO CDAO = new ContactDAO();
                return await CDAO.ContactDeleteAsync(ContactID);
            }
            else
            {
                return new OperationResposneDTO { Status = 0, Message = "Please provide a valid ContactID" };
            }
        }
        #endregion
    }
}
