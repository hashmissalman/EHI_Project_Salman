﻿namespace ContactDemoDTO
{
    public class ContactListDTO
    {
        public int ContactID { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string PhoneNo { get; set; }
        public string ContactStatus { get; set; }
    }
}
