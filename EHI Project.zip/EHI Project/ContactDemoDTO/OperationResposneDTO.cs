﻿namespace ContactDemoDTO
{
    public class OperationResposneDTO
    {
        public int Status { get; set; }
        public string Message { get; set; }
    }
}
