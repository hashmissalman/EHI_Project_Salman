﻿using Microsoft.Extensions.Configuration;
using System.IO;

namespace ContactDemoDTO
{
    public class Common
    {
        /// <summary>
        /// Helper to get application settings from appsettings.json file.
        /// From any application where appsettings.json file is at root level.
        /// </summary>
        public static class ApplicationSettings
        {
            private static readonly IConfigurationRoot root;

            static ApplicationSettings()
            {
                var configurationBuilder = new ConfigurationBuilder();
                configurationBuilder.AddJsonFile(Path.Combine(Directory.GetCurrentDirectory(), "appsettings.json"), false);
                root = configurationBuilder.Build();
            }
            /// <summary>
            /// This method helps to get all elements from applicationsetting.js file.
            /// </summary>
            /// <returns>Returns IConfigurationRoot</returns>
            public static IConfigurationRoot GetAllApplicationSettings()
            {
                return root;
            }

            /// <summary>
            /// This method helps to get value of section which is at root level.
            /// </summary>
            /// <param name="sectionName">Name of root section e.g. ConnectionString</param>
            /// <returns>Section value e.g. Database connection string.</returns>
            public static string GetRootSection(string sectionName)
            {
                return root.GetSection(sectionName).Value;
            }
            /// <summary>
            /// To get database connection string from appsettings.js.
            /// </summary>
            /// <returns></returns>
            public static string DbConnectionString => root["ConnectionStrings:DefaultConnection"].ToString();
        }
    }
}
